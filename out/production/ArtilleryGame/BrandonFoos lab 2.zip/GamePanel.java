import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.BorderLayout;
import java.awt.Color;

import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import java.net.URL;

import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class GamePanel extends JPanel
{

	private static final long serialVersionUID = 1L;
	Background background = new Background();
	ArtilleryUnitA tankA = new ArtilleryUnitA();
	ArtilleryUnitB tankB = new ArtilleryUnitB();
	static int angle = 45;
	boolean projectileInSky = false;
	JButton fire;
	static int powerA = 60;
	boolean demoMode = false;
	boolean clouds = false;

	public GamePanel() throws InterruptedException
	{
		setSize(900, 900);
		setLayout(new BorderLayout());
		add(background);

		background.add(controlBar());

		startGame();

	}

	public void startGame() throws InterruptedException
	{
		if(clouds)
			startClouds();
		tankA.setX(309);
		tankA.setY(436);
		background.add(tankA);

		tankB.setX(679);
		tankB.setY(456);
		background.add(tankB);

	}

	private void startClouds()
	{
		Timer cloudTimer = new Timer();
		
		TimerTask cloudTask = new TimerTask() 
		{

			@Override
			public void run()
			{
				
				Clouds cloud = new Clouds();
				background.add(cloud);
				Timer icloudTimer = new Timer();
				
				TimerTask icloudTask = new TimerTask() 
				{
					int y = (20 + (int)(Math.random() * ((135 - 20) + 1)));
					int x = -130;
					
					
					@Override
					public void run()
					{
						cloud.setLocation(x, y);
						
						x += 1;
						if (x > 900)
							icloudTimer.cancel();
						
					}
					
				};
				icloudTimer.schedule(icloudTask, 0,40);
				
			}
			
		};
		cloudTimer.schedule(cloudTask, 0,9000);
		
	}

	public void fireProjectile(ArtilleryBase artilleryBase, int angle, int power)
	{
		URL sound = this.getClass().getResource("Sounds/drop.wav");

		AudioClip drop = Applet.newAudioClip(sound);
		
		drop.play();
		
		Projectile p = new Projectile();
		background.add(p);

		Timer t = new Timer();

		TimerTask tTask = new TimerTask()
		{
			double x;
			double y;
			double elapsTime;

			public void run()
			{
				projectileInSky = true;
				if(demoMode == false)
					fire.setEnabled(false);
				elapsTime += 0.06;
				x = artilleryBase.getX() + (power * elapsTime * Math.cos(angle * Math.PI / 180));
				y = artilleryBase.getY()
						- (power * elapsTime * Math.sin(angle * Math.PI / 180) - ((9.806 * Math.pow(elapsTime, 2)) / 2));
				// System.out.println(x + ","+y);
				p.setLocation((int) x, (int) y);

				if (checkHit(x, y, artilleryBase))
				{
					//drop.stop();
					background.remove(p);
					repaint();
					projectileInSky = false;
					fire.setEnabled(true);
					t.cancel();
				}

			}
		};
		t.schedule(tTask, 0, 4);

	}

	public boolean checkHit(double x, double y, ArtilleryBase artilleryBase)
	{
		x += 0;
		y += 0;
		if (x < 0 || x > 899)
		{
			x = 0;
			y=0;
			miss(-30,-30);
			return true;
		}
		if ( y > 699)
		{
			y = 0;
			x=0;
			miss(-30,-30);
			return true;
		}
		int[][][] groundArray = Background.getGroundArray();

		try
		{
		if (groundArray[(int) x][(int) y][3] > 0)
		{	
			miss((int)x-20,(int)y-20);
			background.hit((int)x+3,(int)y);
			return true;
		} else if (groundArray[(int) x][(int) y][3] < 1)
		{
			return false;
		}
		} catch(ArrayIndexOutOfBoundsException e)
		{
			e.printStackTrace();
		}
		return false;

	}

	public JPanel controlBar() 
	{
		JPanel controlsPanel = new JPanel();
		URL imgURL = this.getClass().getResource("imgg/fire.png");
		BufferedImage img = new BufferedImage(136,47, BufferedImage.TYPE_INT_RGB);
		try
		{
			img = ImageIO.read(imgURL);

		} catch (IOException e)
		{
			e.printStackTrace();
		}
		ImageIcon fireImg = new ImageIcon(img);
		fire = new JButton(fireImg);
		fire.setSize(136, 47);
		fire.setBorder(BorderFactory.createEmptyBorder());
		fire.setEnabled(true);
		fire.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e)
			{
				if (!projectileInSky || demoMode)
				{
					fireProjectile(tankA,angle,powerA);
				}
				if(demoMode)
				{
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				fireProjectile(tankA,45 + (int)(Math.random() * ((135 - 45) + 1)),60);
				}
				
			}
			
		});
		URL angleURL = this.getClass().getResource("imgg/angle.png");
		BufferedImage angleI = new BufferedImage(136,47, BufferedImage.TYPE_INT_RGB);
		try
		{
			angleI = ImageIO.read(angleURL);

		} catch (IOException e)
		{
			e.printStackTrace();
		}
		ImageIcon angleImg = new ImageIcon(angleI);
		JButton angleBtn = new JButton(String.valueOf(angle));
		angleBtn.setSize(45, 47);
		angleBtn.setFont(new Font("Futura", Font.PLAIN, 30));
		angleBtn.setIcon(angleImg);
		angleBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		angleBtn.setVerticalTextPosition(SwingConstants.CENTER);
		angleBtn.setForeground(new Color(255,255,255));
		angleBtn.setBorder(BorderFactory.createEmptyBorder());
		
		URL leftURL = this.getClass().getResource("imgg/left.png");
		BufferedImage leftI = new BufferedImage(136,47, BufferedImage.TYPE_INT_RGB);
		try
		{
			leftI = ImageIO.read(leftURL);

		} catch (IOException e)
		{
			e.printStackTrace();
		}
		ImageIcon leftImg = new ImageIcon(leftI);
		JButton leftBtn = new JButton(leftImg);
		leftBtn.setSize(45, 47);
		leftBtn.setBorder(BorderFactory.createEmptyBorder());
		leftBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e)
			{
				angle += 1;
				angleBtn.setText(String.valueOf(angle));
				
			}
			
		});
		
		
		
		
		URL rightURL = this.getClass().getResource("imgg/right.png");
		BufferedImage rightI = new BufferedImage(136,47, BufferedImage.TYPE_INT_RGB);
		try
		{
			rightI = ImageIO.read(rightURL);
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		ImageIcon rightImg = new ImageIcon(rightI);
		JButton rightBtn = new JButton(rightImg);
		rightBtn.setSize(45, 47);
		rightBtn.setBorder(BorderFactory.createEmptyBorder());
		rightBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e)
			{
				angle -= 1;
				angleBtn.setText(String.valueOf(angle));
			}
			
		});
		JPanel margin = new JPanel();
		margin.setOpaque(false);
		margin.setSize(200,75);
		margin.setBorder(BorderFactory.createEmptyBorder());
		
		
		ImageIcon powerImg = new ImageIcon(angleI);
		JButton powerBtn = new JButton(String.valueOf(powerA));
		powerBtn.setSize(45, 47);
		powerBtn.setFont(new Font("Futura", Font.PLAIN, 30));
		powerBtn.setIcon(powerImg);
		powerBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		powerBtn.setVerticalTextPosition(SwingConstants.CENTER);
		powerBtn.setForeground(new Color(255,255,255));
		powerBtn.setBorder(BorderFactory.createEmptyBorder());
		
		JButton leftPowBtn = new JButton(leftImg);
		leftPowBtn.setSize(45, 47);
		leftPowBtn.setBorder(BorderFactory.createEmptyBorder());
		leftPowBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e)
			{
				powerA -= 1;
				powerBtn.setText(String.valueOf(powerA));
				
			}
			
		});
	
		JButton rightPowBtn = new JButton(rightImg);
		rightPowBtn.setSize(45, 47);
		rightPowBtn.setBorder(BorderFactory.createEmptyBorder());
		rightPowBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e)
			{
				powerA += 1;
				powerBtn.setText(String.valueOf(powerA));
			}
			
		});
		controlsPanel.add(leftPowBtn);
		controlsPanel.add(powerBtn);
		controlsPanel.add(rightPowBtn);
		controlsPanel.add(margin);
		controlsPanel.add(leftBtn);
		controlsPanel.add(angleBtn);
		controlsPanel.add(rightBtn);
		controlsPanel.add(margin);
		controlsPanel.add(margin);
		controlsPanel.add(fire);
		controlsPanel.setSize(900, 100);
		controlsPanel.setOpaque(false);
		controlsPanel.setLocation(0, 600);

		return controlsPanel;
	}
	
	public void miss(int x , int y){
		Miss missImg = new Miss();
		
		background.add(missImg);
		
		ExplodeIcon e = new ExplodeIcon();
		e.setLocation((int)x, (int)y);
		background.add(e);
		Timer miss = new Timer();
		TimerTask missTask = new TimerTask() {

			@Override
			public void run()
			{
				background.remove(missImg);

				repaint();
			}
			
			
		};
		miss.schedule(missTask, 2000);
		
		Timer icon = new Timer();
		TimerTask iconTask = new TimerTask() {

			@Override
			public void run()
			{
				background.remove(e);
				repaint();
			}
			
			
		};
		icon.schedule(iconTask, 800);
		
	}

	public void impact(int x, int y)
	{
		
	}

	public void explosion(ArtilleryBase artilleryBase)
	{
		
	}
}
