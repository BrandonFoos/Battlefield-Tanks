import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class ArtilleryGame extends JFrame
{

	private static final long serialVersionUID = 1L;
	//TODO: fix clouds from updating with background
	public ArtilleryGame() throws InterruptedException
	{
		setSize(898,685);
		setLocationRelativeTo(null);
		setTitle("Tank Game");
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		add(new GamePanel());

		setVisible(true);
		
	}
	
	public static void displayCredits()
	{
		JOptionPane.showMessageDialog(null, new CreditsPanel(), "Tank Game", JOptionPane.PLAIN_MESSAGE);
	}
	public static void main(String[] args) throws InterruptedException
	{
		new ArtilleryGame();

		//displayCredits();

		
	}
	
}
